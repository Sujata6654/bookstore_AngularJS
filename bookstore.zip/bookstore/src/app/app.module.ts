import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BooksComponent } from './books/books.component';
import { BookDetailsComponent } from './book-details/book-details.component';
//import Routes, RouterModule
import { Routes, RouterModule } from '@angular/router';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';

const routes:Routes=[{path:"books",component:BooksComponent},
{path:"book-details",component:BookDetailsComponent},
{path:"books/:id/:bookName/:authorName/:cost",component:BookDetailsComponent},
{path:"",redirectTo:"/books",pathMatch:"full"},
{path:"**",component:PagenotfoundComponent}];

@NgModule({
  declarations: [
    AppComponent,
    BooksComponent,
    BookDetailsComponent,
    PagenotfoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
