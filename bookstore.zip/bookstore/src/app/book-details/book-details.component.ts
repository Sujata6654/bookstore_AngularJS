import { Component, OnInit } from '@angular/core';
//import ActivatedRoute
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router){ }

  ngOnInit(): void {
  }

  //creating route variable
  id = this.route.snapshot.paramMap.get("id");
  bookName = this.route.snapshot.paramMap.get("bookName");
  authorName = this.route.snapshot.paramMap.get("authorName");
  cost = this.route.snapshot.paramMap.get("cost");

}
