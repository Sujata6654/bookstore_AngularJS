import { Component, OnInit } from '@angular/core';
//import Router 
import { Router } from "@angular/router";

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  books=[
  {id:1,bookName:"Science",authorName:"Sanyam Das",cost:200},
  {id:2,bookName:"Hindi",authorName:"Juhi Kumari Singh",cost:100},
  {id:3,bookName:"Mathematics",authorName:"Dinesh Chouhan",cost:400},
  {id:4,bookName:"English",authorName:"Prem Kumar",cost:200}
  ];

  selectBook(book:any){
    this.router.navigate(["/books",book.id,book.bookName,book.authorName,book.cost]);
  }

}
